-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Nov 2022 pada 14.23
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_paswa`
--
CREATE DATABASE IF NOT EXISTS `db_paswa` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_paswa`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_kegiatan`
--

CREATE TABLE `tab_kegiatan` (
  `id` int(2) NOT NULL,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `narasumber` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_kelompok`
--

CREATE TABLE `tab_kelompok` (
  `id` int(2) NOT NULL,
  `nama_kelompok` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tab_kelompok`
--

INSERT INTO `tab_kelompok` (`id`, `nama_kelompok`) VALUES
(2, 'bunga_mawar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_panitia`
--

CREATE TABLE `tab_panitia` (
  `nim` int(15) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(14) NOT NULL,
  `jabatan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_perlengkapan`
--

CREATE TABLE `tab_perlengkapan` (
  `id` int(2) NOT NULL,
  `perlengkapan` text NOT NULL,
  `kategori` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_peserta`
--

CREATE TABLE `tab_peserta` (
  `nim` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `prodi` text DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  `kelas` varchar(10) DEFAULT NULL,
  `no_hp` varchar(13) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `jenis_kelamin` varchar(11) DEFAULT NULL,
  `foto` text DEFAULT NULL,
  `agama` varchar(10) DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `tab_peserta`
--

INSERT INTO `tab_peserta` (`nim`, `nama`, `prodi`, `semester`, `kelas`, `no_hp`, `email`, `alamat`, `jenis_kelamin`, `foto`, `agama`, `tempat_lahir`, `tanggal_lahir`) VALUES
(1, 'dea', 'si', 3, 'malam', '123', 'dea@hdhd.com', 'asrama', 'perempuan', NULL, 'islam', 'jakarta', '2020-11-03'),
(2, 'dea', 'si', 3, 'malam', '123', 'dea@hdhd.com', 'asrama', 'perempuan', NULL, 'islam', 'jakarta', '2020-11-03'),
(3, 'dea', 'si', 3, 'malam', '123', 'dea@hdhd.com', 'asrama', 'perempuan', NULL, 'islam', 'jakarta', '2020-11-03'),
(4, 'dea', 'si', 3, 'malam', '123', 'dea@hdhd.com', 'asrama', 'perempuan', NULL, 'islam', 'jakarta', '2020-11-03'),
(5, 'dea', 'si', 3, 'malam', '123', 'dea@hdhd.com', 'asrama', 'perempuan', NULL, 'islam', 'jakarta', '2020-11-03'),
(6, 'dea', 'si', 3, 'malam', '123', 'dea@hdhd.com', 'asrama', 'perempuan', NULL, 'islam', 'jakarta', '2020-11-03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_peserta_kelompok`
--

CREATE TABLE `tab_peserta_kelompok` (
  `id` int(2) NOT NULL,
  `nim` int(11) NOT NULL,
  `id_kelompok` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_tamu`
--

CREATE TABLE `tab_tamu` (
  `id` int(2) NOT NULL,
  `nama_tamu` varchar(100) NOT NULL,
  `jabatan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_tata_tertib`
--

CREATE TABLE `tab_tata_tertib` (
  `id` int(2) NOT NULL,
  `tata_tertib` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tab_user`
--

CREATE TABLE `tab_user` (
  `id` int(11) NOT NULL,
  `username` varchar(15) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `created_by` varchar(15) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `update_by` varchar(15) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `tab_user`
--

INSERT INTO `tab_user` (`id`, `username`, `password`, `lastlogin`, `created_by`, `created_at`, `update_by`, `update_at`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tab_kegiatan`
--
ALTER TABLE `tab_kegiatan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tab_kelompok`
--
ALTER TABLE `tab_kelompok`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tab_panitia`
--
ALTER TABLE `tab_panitia`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `tab_perlengkapan`
--
ALTER TABLE `tab_perlengkapan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tab_peserta`
--
ALTER TABLE `tab_peserta`
  ADD PRIMARY KEY (`nim`) USING BTREE;

--
-- Indeks untuk tabel `tab_peserta_kelompok`
--
ALTER TABLE `tab_peserta_kelompok`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tab_tamu`
--
ALTER TABLE `tab_tamu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tab_tata_tertib`
--
ALTER TABLE `tab_tata_tertib`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tab_user`
--
ALTER TABLE `tab_user`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tab_kegiatan`
--
ALTER TABLE `tab_kegiatan`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tab_kelompok`
--
ALTER TABLE `tab_kelompok`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tab_perlengkapan`
--
ALTER TABLE `tab_perlengkapan`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tab_peserta`
--
ALTER TABLE `tab_peserta`
  MODIFY `nim` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tab_peserta_kelompok`
--
ALTER TABLE `tab_peserta_kelompok`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tab_tamu`
--
ALTER TABLE `tab_tamu`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tab_tata_tertib`
--
ALTER TABLE `tab_tata_tertib`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tab_user`
--
ALTER TABLE `tab_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
